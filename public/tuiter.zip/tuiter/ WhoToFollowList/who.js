const who = [ { avatarIcon: '../../images/java.jfif',
userName: 'Java', handle: 'Java', },
{ avatarIcon: '../../images/space.jfif',
userName: 'Relativity Space',
handle: 'relativityspace', },
{ avatarIcon: '../../images/virgin.png',
userName: 'Virgin Galactic',
handle: 'virgingalactic', },
{ avatarIcon: '../../images/nasa.png',
userName: 'NASA', handle: 'NASA', },
{ avatarIcon: '../../images/tesla.jfif',
userName: 'Tesla', handle: 'Tesla', }, ];

export default who;